### Running the server
To run the server, run:

```
npm start
```
